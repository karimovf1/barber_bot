
# Bot kodi shu yerga kiritiladi (soddalashtirilgan qisqacha versiyasi)
# To'liq kodni yuklab olish uchun fayl yaratamiz
